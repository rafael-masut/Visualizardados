There are two known improvements which might be addressed in future versions:

- Vertical alignment of the button is currently now possible.
- Improvement for the mobile view, reserve less space for the export button.
- Would be nice to have some kind of spinner in case of the client export
