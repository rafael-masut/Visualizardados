***sense-export*** is designed to work with Qlik Sense 2.1.1 or higher.
If you use the visualization extension in an older version of Qlik Sense the following message will be shown:

![Unsupported message]({%= verb.baseImgUrl %}docs/images/unsupported.png)
