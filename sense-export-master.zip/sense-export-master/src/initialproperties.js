/* global define */
define([], function () {
  'use strict';
  return {
    qHyperCubeDef: {
      qDimensions: [],
      qMeasures: [],
      qInitialDataFetch: [
        {
          qWidth: 20,
          qHeight: 500
        }
      ]
    }
  };
});
