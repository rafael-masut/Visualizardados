                                                                 
                                                                 
            `/++/`                                               
            .oooo.                                               
            .oooo.                                               
    `--.    .oooo.    .--`                                       
  `:+oo+`   .oooo.   `+oo+:`      Qlik Sense Governance Collector
 .+ooo+-    .oooo.    -+ooo+.     Presented by:                  
`+ooo/`     .+oo+.     `/ooo+`    Renato Viera                   
/ooo+`       -:::-`     `+ooo/    Vincenzo Esposito              
+ooo:    `/-   -s/`..    /ooo+    Loic Formont                   
+ooo/     `.:.-:so++.    /ooo+    Jeff Goldberg                  
:ooo+.     `-++//:.`    .+ooo:    Michael Terenzi                
`/ooo+.   :/o+-///+`   .+ooo/`                                   
 `/ooo+/. .::` `-/:  ./+ooo/`     Special Thanks to:             
   -+ooo++/-......-/++ooo+-       Dalton Ruer                    
     ./+oooo++++++oooo+/.                                        
        .-:/++++++/:-.                                           
                                                                 
                                                                 