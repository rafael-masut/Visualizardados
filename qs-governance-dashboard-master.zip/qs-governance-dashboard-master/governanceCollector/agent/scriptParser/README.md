# qlik-script-log-parser
nodejs parser module for qlik sense script log files
