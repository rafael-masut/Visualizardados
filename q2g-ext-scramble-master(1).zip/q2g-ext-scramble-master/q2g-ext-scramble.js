define(["./src/q2g-ext-scrambleExtension"], function(scrambler) {
    return scrambler;
});