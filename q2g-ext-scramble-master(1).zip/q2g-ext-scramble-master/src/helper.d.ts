declare module "text!*" {
    var e: string; export = e;
}

interface IQVAngular {

    $injector: angular.auto.IInjectorService;

}

