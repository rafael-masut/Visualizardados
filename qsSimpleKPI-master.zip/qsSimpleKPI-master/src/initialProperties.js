export default {
  version : 1.1,
  qHyperCubeDef: {
    qDimensions: [],
    qMeasures: [],
    qInitialDataFetch: [{
      qWidth: 125,
      qHeight: 80
    }]
  },
  options: {}
}
