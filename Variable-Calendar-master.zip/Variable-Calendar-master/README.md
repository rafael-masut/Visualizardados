# Variable-Calendar

It's a Object Calendar made with jquery library. Based on variable, it changes the value everytime you select a date.

![calendar](https://cloud.githubusercontent.com/assets/16780506/13328132/5d2a8d94-dbed-11e5-9f49-0fc22712b425.PNG)

Usage:

1- put the project into the directory Documents/Qlik/Sense/Extensions

2- set a variable date into the script (DD/MM/YYYY)

3- change object proprerties and set variable name as the variable before set (don't worry if an error occured. The object will take variable's value)

4- everytime you change date the variable's value will be DD/MM/YYYY selected

Visit http://www.primenet.it/
