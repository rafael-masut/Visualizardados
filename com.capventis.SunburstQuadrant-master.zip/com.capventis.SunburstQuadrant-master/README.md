com.capventis.SunburstQuadrant
==============================

The Sunburst Quadrant visualizes hierarchical data.

Because it occupies only a quadrant, it is slightly more space efficient than a circular sunburst object.  This means that it also gives more space to the actual data.

