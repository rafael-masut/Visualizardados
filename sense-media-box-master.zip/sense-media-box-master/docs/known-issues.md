* Video doesn't work in Qlik Sense Desktop but in local browser or Qlik Sense server.
* Some websites [do not allow](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-Frame-Options) to be included via Iframe (which is used for the media-type website). You'll see a corresponding message in your browser's debug log.
