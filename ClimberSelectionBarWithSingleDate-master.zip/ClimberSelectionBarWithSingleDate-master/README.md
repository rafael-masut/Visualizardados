ClimberSelectionBar belogs to **Karl Fredberg Sjöstrand**. Our changes honors the **MIT** license provided by the author
