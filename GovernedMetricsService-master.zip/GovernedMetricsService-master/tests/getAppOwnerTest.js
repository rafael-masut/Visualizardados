var getAppOwner = require('./getAppOwner');

getAppOwner.getAppOwner('831bc2ea-a43b-46f7-9ad2-d843cb9c4764')
.then(function(result)
{
    console.log(result);
});