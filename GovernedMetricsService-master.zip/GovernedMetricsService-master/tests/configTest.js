var testConfig = require('./testConfig');

console.log(JSON.stringify(testConfig));

console.log(testConfig.certificates.client);