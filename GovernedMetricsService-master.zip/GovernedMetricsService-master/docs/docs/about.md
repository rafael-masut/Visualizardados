![Powertools logo](https://s3.amazonaws.com/eapowertools/governedmetricsservice/img/PowerToolsLogoNew.png)

Copyright 2016, EA Powertools

For more information, check out the [EA Powertools page](https://community.qlik.com/community/qlik-sense/ea-powertools) on Qlik Community
