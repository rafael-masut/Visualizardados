<h2>Welcome to EA Powertools Governed Metrics Service documentation</h2>

To access the Governed Metrics Service project go here: [GitHub: Governed Metrics Service](https://github.com/eapowertools/GovernedMetricsService).

Use the menu sidebar on the left to access the installation and user guides for the Governed Metrics Service.
