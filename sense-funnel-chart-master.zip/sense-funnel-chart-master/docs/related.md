Some related projects (Qlik Sense Visualization Extensions) I have recently created:

{%= related([
  'sense-media-box', 
  'sense-themable-kpi-tile', 
  'sense-on-off-switch', 
  'qliksense-extension-tutorial',
  'sense-extension-recipes'
  ], {"silent": true}
) %}  