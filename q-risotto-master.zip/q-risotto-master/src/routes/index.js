//required file for require-hapiroutes.  Make it easier to setup routes to js files

var requireHapiRoutes = require('require-hapiroutes');
module.exports = requireHapiRoutes(module);
