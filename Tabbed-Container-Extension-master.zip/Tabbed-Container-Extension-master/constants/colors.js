define([], function(){
    return {
        palette: [
            "#b0afae", "#7b7a78", "#545352", "#4477aa", "#7db8da",
            "#b6d7ea", "#46c646", "#f93f17", "#ffcf02", "#276e27",
            "#ffffff", "#000000"
        ],
        inactive: { background: '#f2f2f2', border: '#e6e6e6' }
    }
})
