define( [], function () {
    'use strict';
    return {
	
       qHyperCubeDef : {
				qDimensions : [],
				qMeasures : [],
				qInitialDataFetch : [{
					qWidth : 0,
					qHeight : 0
				}]
			}
    };
} );